#include <stdlib.h>
#include <limits.h>  /* for USHRT_MAX */

#include <immintrin.h>

#include "min.h"
/* reference implementation in C */
short min_C(long size, short * a) {
    short result = SHRT_MAX;
    for (int i = 0; i < size; ++i) {
        if (a[i] < result)
            result = a[i];
    }
    return result;
}
short min_AVX(long size, short * a){
  __m256i partial_mins = _mm256_setr_epi16(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],a[15]);
  for (int i = 16; i < size; i += 16){
    __m256i current  = _mm256_setr_epi16(a[i],a[i+1],a[i+2],a[i+3],a[i+4],a[i+5],a[i+6],a[i+7],a[i+8],a[i+9],a[i+10],a[i+11],a[i+12],a[i+13],a[i+14],a[i+15]);
    partial_mins = _mm256_min_epi16(current, partial_mins);
  }
  unsigned short extracted_partial_mins[16];
  _mm256_storeu_si256((__m256i*) &extracted_partial_mins, partial_mins);
  short min = 32767;
  for (int j = 0; j < 16; j++){
    if (extracted_partial_mins[j] < min){
      min = extracted_partial_mins[j];
    }
  }
  return min;
}


/* This is the list of functions to test */
function_info functions[] = {
    {min_C, "C (local)"},
    // add entries here!
    {min_AVX, ""}
};
